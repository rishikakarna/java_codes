package com.lti.training.day7.io;

import java.io.Serializable;

public class Employee implements Serializable {

	private int empno;
	private String name;
	private transient double salary;
	// transient --in memory here 30000 remains in memory bt o/p remains default i.e 0.0

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	/**
	 * @param empno
	 * @param name
	 * @param salary
	 */
	public Employee(int empno, String name, double salary) {
		super();
		this.empno = empno;
		this.name = name;
		this.salary = salary;
	}

	/**
	 * 
	 */
	public Employee() {
		super();
	}
}
