package com.lti.training.day7.io;

//for image processing....imageio class
//this program copies the data of file to another using buffer

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;

public class QuickWriteTextFile {

	public static void main(String[] args) {
		FileWriter outFile = null;
		FileReader inFile = null;
		BufferedReader inBuffer = null;
		BufferedWriter outBuffer = null;
		try {
			inFile = new FileReader("sample.txt");
			outFile = new FileWriter("copyofsample.txt");
			inBuffer = new BufferedReader(inFile, 1024 * 16);
			outBuffer = new BufferedWriter(outFile, 1024 * 16);

			String line = null;
			while (true) {
				line = inBuffer.readLine();
				if (line == null) // EOF
					break;
				line = line.toUpperCase();
				outBuffer.write(line);
				outBuffer.newLine();
			}
			System.out.println("File copied successfully");

		} catch (FileNotFoundException e) {
			System.out.println("Please check the no.of of your glasses!");
		} catch (IOException e) {
			System.out.println("Please contact Mr Santosh");
		} finally {
			try {
				inBuffer.close();
			} catch (Exception e) {
			}
			try {
				outBuffer.close();
			} catch (Exception e) {
			}
			try {
				inFile.close();
			} catch (Exception e) {
			}
			try {
				outFile.close();
			} catch (Exception e) {
			}
		}
	}
}
