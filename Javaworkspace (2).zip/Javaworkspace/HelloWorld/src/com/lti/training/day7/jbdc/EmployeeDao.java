package com.lti.training.day7.jbdc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.training.day7.io.Employee;

//data access object
public class EmployeeDao {

	// public void insert(int empno, String ename, double salary)
	// to insert
	public void store(Employee emp) throws DataAccessException {
		Connection conn = null;
		PreparedStatement pstmt = null; // precompiled sql statements
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");

			// Insert into Tbl_emp values(1001,"Luffy",30000)
			pstmt = conn.prepareStatement("insert into TBL_EMP values(?,?,?)");
			pstmt.setInt(1, emp.getEmpno());
			pstmt.setString(2, emp.getName());
			pstmt.setDouble(3, emp.getSalary());
			pstmt.executeUpdate(); // any dml command
		} catch (Exception e) {
			throw new DataAccessException("problem while inserting emp data", e);
		} finally {
			try {
				pstmt.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		// select * statement

	}

	public List<Employee> fetchAll() throws DataAccessException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@infva06863:1521:xe", "hr", "hr");
			pstmt = conn.prepareStatement("select * from TBL_EMP");
			rs = pstmt.executeQuery(); // select

			List<Employee> list = new ArrayList<>();
			while (rs.next()) {
				Employee emp = new Employee();
				emp.setEmpno(rs.getInt("empno"));
				emp.setName(rs.getString("name"));
				emp.setSalary(rs.getDouble("salary"));
				list.add(emp);
			}
			return list;
		} catch (ClassNotFoundException | SQLException e) {
			throw new DataAccessException("problem while inserting emp data", e);
		} finally {
			try {
				pstmt.close();
			} catch (Exception e) {
			}
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}
}
