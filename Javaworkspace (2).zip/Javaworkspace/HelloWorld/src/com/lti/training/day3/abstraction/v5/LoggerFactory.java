package com.lti.training.day3.abstraction.v5;

//factory degin pattern 

public class LoggerFactory {

		public static Logger getLoggerInstance() {
			return new ConsoleLogger();
		}
}
