package com.lti.training.day3.abstraction.v6;
//implements: bcoz of interface
import java.io.FileWriter;
import java.io.IOException;
/**
 * @author 
 * @version 1.2
 * 
 */
import java.time.LocalDate;
import java.time.LocalDateTime;

public class FileLogger implements Logger {

	@Override
	public void log(String msg, LogLevel level) {
		try(FileWriter fw = new FileWriter("app.log", true)) {
		switch (level) {
		case INFO:
			fw.write("[INFO] ["+LocalDateTime.now()+"]"+ " " + msg);
			break;
		case WARN:
			fw.write("[WARNING] ["+LocalDateTime.now()+"]"+ " " + msg);
			break;
		case ERROR:
			fw.write("[ERROR] ["+LocalDateTime.now()+"]"+ " " + msg);
			break;
		}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
