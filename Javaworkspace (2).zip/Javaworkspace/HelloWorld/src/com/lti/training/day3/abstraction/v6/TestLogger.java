package com.lti.training.day3.abstraction.v6;

public class TestLogger {

	public static void main(String[ ] args) {
//		Logger logger = new FileLogger();  //polymorphism achieved
//		FileLogger logger = new  FileLogger();
//		ConsoleLogger logger = new  ConsoleLogger();
		Logger logger = LoggerFactory.getLoggerInstance();  
		/*polymorphism/abstraction...logger provides logging feature
		 * not creating obj of Logger since here its an abstract class
		*/
		logger.log("Some happy msg \n");
		logger.log("maybe some concern to address \n", LogLevel.WARN);
		logger.log("some critical situation has arissed \n", LogLevel.ERROR);
	}
}
