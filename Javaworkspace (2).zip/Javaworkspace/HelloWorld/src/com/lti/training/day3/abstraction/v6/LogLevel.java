package com.lti.training.day3.abstraction.v6;

public enum LogLevel {
	INFO, WARN, ERROR

}
