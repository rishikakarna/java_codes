package com.lti.training.day3.abstraction.v5;
/*abstract class: dont have method body just have signature
 * can have constructor
 * 
 */
 
public abstract class Logger {
	
	public void log(String msg) {
			log(msg, LogLevel.INFO);		//reusing 2nd log
		}

	public abstract void log(String msg, LogLevel level);
}
