package com.lti.training.day3.abstraction.v6;
/*interface:can only contain abstract method
 * default: for non-abstract method
 */

public interface Logger {
	/*
	 * from ==java8== onwards interface can contain non-abstract & static methods
	 */
	public default void log(String msg) {
		log(msg, LogLevel.INFO); // reusing 2nd log
	}

	public void log(String msg, LogLevel level);
}
