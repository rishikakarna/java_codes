package com.lti.training.day2.basics;

public class TestPhoneBook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PhoneBook phbk= new PhoneBook(10);
		
		Contact c1 = new Contact("John", "12345", "john@gmail.com", "10/10/1994");
		Contact c2 = new Contact("Russ", "77345", "russ@gmail.com", "11/11/1996");
		Contact c3 = new Contact("Jacky", "476453", "jack@gmail.com", "12/01/1983");
		
		phbk.add(c1);
		phbk.add(c2);
		phbk.add(c3);
		
		phbk.display();
		
		Contact c= phbk.searchByName("Ja");
		if(c != null) {
			System.out.println(c.getName() + " \t " + c.getNumber() + " \t " 
					+ c.getEmail() + " \t " + c.getDob() );
		}
		else
			System.out.println("Not found");	
	}

}
