package com.lti.training.day2.basics;

public class Car {

	//member variables/fields
	//instance/static variables/fields
	//non-static/static variables/fields
	//attributes
	//member variables represent
	//the STATE of the object
	private String model;
	private String year;
	private double price;
	
	//-----------------------------------------------constructor(s)-----------------------------------------------//
	/*
	 @param model
	 @param year
	 @param price
	 */
	public Car(String model, String year, double price) {
		super();
		this.model = model;
		this.year = year;
		this.price = price;
	}
	
	//-----------------------------------------------getters and setters-----------------------------------------------//
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	

	
	
}
