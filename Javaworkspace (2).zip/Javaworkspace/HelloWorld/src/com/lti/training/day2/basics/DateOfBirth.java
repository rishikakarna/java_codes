package com.lti.training.day2.basics;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.*;

public class DateOfBirth {

	public static void main(String[] args) throws Exception
	{
//		LocalDate today = LocalDate.now();                          //Today's date
//		LocalDate birthday = LocalDate.of(1960, Month.JANUARY, 1);  //Birth date
//		 
//		Period p = Period.between(birthday, today);
//		 
//		//Now access the values as below
//		System.out.println(p.getDays());
//		System.out.println(p.getMonths());
//		System.out.println(p.getYears());
		
		
	  Calendar calNewYork = Calendar.getInstance();
	 calNewYork.setTimeZone(TimeZone.getTimeZone("America/New_York"));
	  System.out.println("Time in New York: " + calNewYork.get(Calendar.HOUR_OF_DAY) + ":"
	 + calNewYork.get(Calendar.MINUTE));

	}

}
