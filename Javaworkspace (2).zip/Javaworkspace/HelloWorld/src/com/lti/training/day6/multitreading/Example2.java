package com.lti.training.day6.multitreading;

public class Example2 {

	class SomeTask implements Runnable {
		@Override
		public void run() {
			System.out.println("line 1 executed");
			try {
				Thread.sleep(1000 * 60 * 60); // 1hr
			} catch (InterruptedException e) {
				System.out.println("kisne muje jaghaya??????");
			}
			System.out.println("line 2 executed....");
		}
	}

	void launch() {
		Thread th = new Thread(new SomeTask());
		th.start();
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
		th.interrupt();
	}

	public static void main(String[] args) {

	}
}
