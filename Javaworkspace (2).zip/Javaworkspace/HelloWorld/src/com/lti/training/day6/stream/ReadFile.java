package com.lti.training.day6.stream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public static void main(String[] args) {
		 FileInputStream inFile = null;
//		FileReader inFile = null;
		try {
//			inFile = new FileInputStream("car.jpg"); // Pass name of the file
			inFile = new FileInputStream("D:\\jdk-8u131-windows-x64.exe");
//			inFile = new FileReader("car.jpg"); 
			int ch = 0;
			while (true) {
				ch = inFile.read();
				if (ch == -1) // EOF
					break;
				System.out.print((char) ch);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Please check the no.of of your glasses!");
		} catch (IOException e) {
			System.out.println("Please contact Mr Santosh");
		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
			}
		}

	}

}
