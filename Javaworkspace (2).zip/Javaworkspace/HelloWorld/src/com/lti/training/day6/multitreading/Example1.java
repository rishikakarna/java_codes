package com.lti.training.day6.multitreading;

public class Example1 {

	// inner classes
	class Task1 implements Runnable {
		@Override
		public void run() {
			for (int i = 0; i < 10; i++) {
				System.out.println("task 1 running");
			//	try { Thread.sleep(1);  }  catch(InterruptedException e) { }
				Thread.yield();
			}

		}
	}

	class Task2 implements Runnable {
		@Override
		public void run() {
			for (int i = 0; i < 10; i++) {
				System.out.println("task 2 running");
			//	try { Thread.sleep(1);  }  catch(InterruptedException e) { }
				Thread.yield();
			}
		}
	}

	private void launch() {

		Task1 task1 = new Task1();
		Task2 task2 = new Task2();
		Thread th1 = new Thread(task1);
		Thread th2 = new Thread(task2);
	/*	th1.setPriority(1);                                                 //between 1 & 10  //lowest   
		th2.setPriority(10);																				  //highest
*/		
/*		th1.setPriority(Thread.MIN_PRIORITY);                                                
		th2.setPriority(Thread.MAX_PRIORITY);						*/													 
//		th1.setDaemon(true);
//		th2.setDaemon(true);
		th1.start();
		th2.start();
	}

	public static void main(String[] args) {
		new Example1().launch();
	}
}
