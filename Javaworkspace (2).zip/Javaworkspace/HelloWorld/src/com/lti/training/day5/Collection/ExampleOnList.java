package com.lti.training.day5.Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.lti.training.day3.objectclass.Person;

public class ExampleOnList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// <>angular notation is called generics in java & its optional
		List<String> list1 = new ArrayList<String>();
		// List list1 = new ArrayList();
		list1.add("Java");
		list1.add("Oracle");
		list1.add(".Net");
		list1.add("PHP");
		list1.add("Java");

			
		
		 System.out.println("option 2: using for each-loop"); //most frequently used
		  for (String str : list1) System.out.println(str); 
		  
		/*
		 * // different ways of iterating over the List
		 * 
		 * System.out.println("option 1: old fashioned for loop"); //fastest but
		 * concurrency issues for (int i = 0; i < list1.size(); i++)
		 * System.out.println(list1.get(i));
		 * 
		  System.out.println("option 2: using for each-loop"); //most frequently used
		  for (String str : list1) System.out.println(str);
		 
		 * System.out.println("option 3: Java 8 lambda style for-each");
		 * list1.forEach(str -> System.out.println(str));
		 * 
		 * System.out.println("option 4: traditional iterator"); Iterator<String> itr =
		 * list1.iterator(); while (itr.hasNext()) System.out.println(itr.next());
		 */
//		List<Person> list2 = new ArrayList<>();
//		list2.add(new Person("Angela", 99));
//		list2.add(new Person("Kunal", 99));
//		list2.add(new Person("Pratik", 99));
//		list2.add(new Person("Nabi", 99));
//
//		// for (Person p : list2)
//		// System.out.println(p);
//
//		Iterator<Person> itr = list2.iterator();
//		while (itr.hasNext())
//			System.out.println(itr.next());
		
		 
	}
}
