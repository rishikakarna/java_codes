package com.lti.training.day5.Collection;

//import java.util.ArrayList;
import java.util.List;

//online exam app
public class Question {

	private String question;
	// private Collection<Option> options; //high level abstraction...
	private List<Option> options; // abstraction ..dont want to show that we are using ArrayList
	// private ArrayList<Option> options; // why not array?? bcoz of size,not
	// flexible
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public List<Option> getOptions() {
		return options;
	}
	public void setOptions(List<Option> options) {
		this.options = options;
	}

}
