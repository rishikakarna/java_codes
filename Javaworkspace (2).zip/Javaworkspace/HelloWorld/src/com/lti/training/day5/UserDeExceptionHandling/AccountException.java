package com.lti.training.day5.UserDeExceptionHandling;

public class AccountException extends Exception // for checked else for unchecked: Runtime Exception
// in runtime_Exception "throws" keyword is optional
{
	public AccountException(String msg) {
		super(msg);
	}
}
