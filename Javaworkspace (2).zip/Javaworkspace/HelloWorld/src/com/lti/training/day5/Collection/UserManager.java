package com.lti.training.day5.Collection;

import java.util.ArrayList;
import java.util.List;

public class UserManager {

	private List<User> users;

	public UserManager() {
		users = new ArrayList<User>();
		users.add(new User("ash", "123"));
		users.add(new User("brock", "456"));
		users.add(new User("misty", "788"));
		users.add(new User("pichu", "159"));
	}

	public boolean isValidUser(String username, String password) {

		for (User user : users) {
			if (user.getUsername().equals(username) && user.getPassword().equals(password))
				return true;
		}
		return false;
		
	}

	public static void main(String[] args) {
		UserManager userManager = new UserManager();
		boolean isValid = userManager.isValidUser("ash", "193");
		System.out.println(isValid);
	}
}
