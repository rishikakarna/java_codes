package com.lti.training.day5.wrapperclasses;

public class WrapperClassesExamples {

	public static void main(String[] args) {
		int x = 10;

		Integer y = 20; // autoboxing
		// above line is equivalent to
		Integer z = new Integer(30);

		int a = 10;
		a = 20;

		Integer b = 10; // new object is created
		b = 20; // new object is created again

//		int c = null;
		Integer d = null; // only obj can store null

		/*
		 * some places in java, primitives are not supported, for eg: Collection like
		 * ArrayList, LinkedList and others then we end up using Wrapper classes instead
		 * of primitives
		 * 
		 * apart from this, common use of wrapper classes is type conversion
		 */

		// converting int to Integer
		Integer e = 10; // new Integer(10);
		// converting Integer to int
		int f = e; // e.intValue();
		// converting String to Integer
		Integer g = new Integer("100");
		// converting Integer to string
		String h = g.toString();
		// converting String to Int
		int i = Integer.parseInt("100");
		// converting Int to String
		String j = Integer.toString(100);

		// todo :: try this--> int--.>String-->float-->Double-->Integer
		
		String k = Integer.toString(100);
		float l = Float.parseFloat("100");
//		Double n = Double.parseDouble();
		Double n = new Double(40);
		
	}

}
