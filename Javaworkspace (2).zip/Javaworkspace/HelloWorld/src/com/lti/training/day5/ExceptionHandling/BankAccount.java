package com.lti.training.day5.ExceptionHandling;

public class BankAccount {

	private int acno;
	private String name;
	private double balance;

	public BankAccount(int acno, String name, double balance) {
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}

	public double withdraw(double amount) throws RuntimeException {
		if (amount > balance) {
			RuntimeException e = new RuntimeException("Insufficient paisa");
			throw e;

		} else {
			balance -= amount;
			return balance;

		}
	}

	public static void main(String[] args) {
		BankAccount bankAcc = new BankAccount(1001, "LUFFY", 5000);
		try {
			double balance = bankAcc.withdraw(60000);
			System.out.println("Blance left" + balance);

		} catch (Exception e) {
			// System.out.println(e.getMessage());
			e.printStackTrace();
			// detail info of Exception/Error....no need to inform end user..not used in
			// live project

		}
	}
}
