package practice;

public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public int totalEmployees() {
		// TODO Auto-generated method stub
		return 1000;
	}

	public String designition() {
		// TODO Auto-generated method stub
		return null;
	}

	public double salary() {
		// TODO Auto-generated method stub
		return 0;
	}

}
