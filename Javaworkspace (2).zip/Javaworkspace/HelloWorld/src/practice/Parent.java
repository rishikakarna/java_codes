package practice;

public class Parent {

	int x=10;
	public void add()
	{
		System.out.println("parent class add method");
	}
	public void mul()
	{System.out.println("parent class mul method");}
}
