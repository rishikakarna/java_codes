package assignment1;

import java.util.Arrays;

public class Toy implements Cloneable {

	private String name;
	private Battery[] batteries;
	private int count;



public Toy() {
	// TODO Auto-generated constructor stub
}
	/**
	 * @param name
	 * @param batteries
	 */
	public Toy(String name, int noOfBatteries) {
		super();
		this.name = name;
		this.batteries = new Battery[noOfBatteries];
	}

	public void addbattery(String batteryName) {

		Battery battery = new Battery(batteryName, count);
		batteries[count++] = battery;
	}

	@Override
	public String toString() {
		return "Toy [name=" + name + ", batteries=" + Arrays.toString(batteries) + ", count=" + count + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Battery[] getBatteries() {
		return batteries;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		Toy t = (Toy) super.clone();
		Battery[ ] newBatteries = new Battery[batteries.length];
		for(int i= 0 ; i<batteries.length ; i++)
			newBatteries[i] = (Battery) batteries[i].clone();
			t.setBatteries(newBatteries);
		return t;
	}
}