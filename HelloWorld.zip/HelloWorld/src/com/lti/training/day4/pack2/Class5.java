package com.lti.training.day4.pack2;

import com.lti.training.day4.pack1.Class1;

public class Class5 {

	void check() {
		Class1 obj = new Class1();
		System.out.println(obj.a);
		System.out.println(obj.b);
		System.out.println(obj.c);
		System.out.println(obj.d);

	}
}
