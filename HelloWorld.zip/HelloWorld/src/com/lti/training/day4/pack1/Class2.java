package com.lti.training.day4.pack1;

public class Class2 extends Class1 {

	void check() {
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}
