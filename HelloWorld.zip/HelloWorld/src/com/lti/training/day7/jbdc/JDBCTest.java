package com.lti.training.day7.jbdc;

import com.lti.training.day7.io.Employee;

public class JDBCTest {

	public static void main(String[] args) {
		EmployeeDao empDao = new EmployeeDao();
		
		Employee emp = new Employee();
		emp.setEmpno(111);
		emp.setName("Luffy");
		emp.setSalary(10000);
		
		try {
			empDao.store(emp);
		}
		catch(DataAccessException e) {
			e.printStackTrace();
		}

	}

}
