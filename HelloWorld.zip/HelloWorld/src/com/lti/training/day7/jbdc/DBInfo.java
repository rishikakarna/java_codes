
package com.lti.training.day7.jbdc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBInfo {
	public static void main(String[] args) {
		Connection conn = null;
		try {
			// Step1. Loading JDBC driver
			Class.forName("oracle.jdbc.driver.OracleDriver"); // Reflection API// load driver

			// Step2 Now we can try connecting to database

			String url = "jdbc:oracle:thin:@infva06863:1521:xe";
			String user = "hr";
			String pass = "hr";
			conn = DriverManager.getConnection(url, user, pass);

			// let's try printing some details about the db we connecting to
			DatabaseMetaData dbms = conn.getMetaData();
			System.out.println("DB Name " + dbms.getDatabaseProductName());
			System.out.println("DB Version " + dbms.getDatabaseProductVersion());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Please check if driver jar is present in class path");
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (Exception ignored) {
			}
		}
	}
}
