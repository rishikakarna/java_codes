package com.lti.training.day7.io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationEg {

	private static void serialize() throws Exception {

		FileOutputStream f = new FileOutputStream("emp.txt");
		ObjectOutputStream os = new ObjectOutputStream(f); // stores obj in file

		Employee e = new Employee();
		e.setEmpno(1001);
		e.setName("Luffy");
		e.setSalary(30000);

		os.writeObject(e); // serialization- saving state of an object

		os.close();
		f.close();
	}

	private static void deserialize() throws Exception {
		FileInputStream f = new FileInputStream("emp.txt");
		ObjectInputStream os = new ObjectInputStream(f);

		Employee e = (Employee) os.readObject();

		System.out.println(e.getEmpno());
		System.out.println(e.getName());
		System.out.println(e.getSalary());

		os.close();
		f.close();
	}

	public static void main(String[] args) throws Exception {
		serialize();
		deserialize();
	}
}
