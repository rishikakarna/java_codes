package com.lti.training.day2.basics;

public class BinDec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		int x= 64;
 System.out.println("Binary of  " + x + "=" + Integer.toBinaryString(x));
 System.out.println("Octal of  " + x + "=" + Integer.toOctalString(x));
 System.out.println("Hexadecimal of  " + x + "=" + Integer.toHexString(x));
 	}

}
