package com.lti.training.day2.basics;

public class Calculator {

		// TODO Auto-generated method stub
		public void add(int x, int y) {
			System.out.println("addition = " + (x+ y) );
			}
		public void sub(int x, int y) {
			System.out.println("subtraction = " + (x- y));
			}
		public static void divide(int x, int y) {
			System.out.println("division = " + (x/ y));
			}
		public static void mul(int x, int y) {
			System.out.println("multiplication = " + (x* y) );
			}
		
		public static void main(String[] args) {
			Calculator a = new Calculator(); 
			a.add(10, 10);
			a.sub(10, 10);
//			a.divide(10, 10);
//			a.mul(10, 10);
			Calculator.divide(10, 10);
			Calculator.mul(10, 10);
		}
		}
