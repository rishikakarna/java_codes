
package com.lti.training.day2.basics;

import java.util.Scanner;

public class PhoneBook 
{
	
	private Contact[] contacts;
	private int count;
	//default constructor
	public PhoneBook()
	{
		contacts = new Contact[100];
	}
	//parameterized constructor
	public PhoneBook(int noOfEntries) 
	{
		contacts = new Contact[noOfEntries];
	}
	
	void add(Contact contact) 
	{
		contacts[count++] = contact;	
	}
	
	public void display() 
	   {
		for(int i=0; i<count; i++)
		{
			System.out.println(contacts[i].getName() + " \t " + contacts[i].getNumber() + " \t " 
					+ contacts[i].getEmail() + " \t " + contacts[i].getDob() );
		}
	}
	
	public Contact searchByName(String name)
	{
			
		for(int i=0; i<count; i++)
		{
			if(contacts[i].getName() == name)
			return contacts[i];
		}
		return null;
	}
	
	public Contact searchByNumber(String number) 
	{
		return null;
	}
	
	public void clear() {
		
	}
	
}
