package com.lti.training.day2.basics;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TestCar {

		public static void main(String[] args) {
			//create an object
			//Car c1 = new Car("Maruti 800", "1995", 50000);
			Date d = new Date();
			
			SimpleDateFormat formatdate = new SimpleDateFormat("dd/EEE/MMMM/yyyy");
			LocalDateTime now = LocalDateTime.now();

			String sdate = formatdate.format(d);
			System.out.println(sdate);
			/*
			c1.setPrice(20000);
			System.out.println(d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds());
			System.out.println(c1.getModel() + ", " + c1.getPrice() + ", " + c1.getYear());
			
			Runtime r = Runtime.getRuntime();
			long total = r.totalMemory() / 1024 / 1024;
			long freem = r.freeMemory() / 1024 / 1024;
			long maxm = r.maxMemory() / 1024 / 1024;
			
			//System.out.println("tot mem" + r.totalMemory());
			System.out.println("tot mem " + total + "mb approx");
			System.out.println("free mem " + freem + "mb approx");
			System.out.println("max mem " + maxm + "mb approx");
			*/
			int dd = 9;
			int mm = 1;
			int yyyy = 2019;
			
			Calendar cal = Calendar.getInstance();
			cal.set(yyyy, mm - 1, dd);
			int day = cal.get(Calendar.DAY_OF_WEEK);
			String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}; 
			System.out.println("Day is/was " + days[day - 1]);
			
		}
}
