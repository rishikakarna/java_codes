package com.lti.training.day3.interfaces;

/**
 * 
 * @author Google Inc
 *
 */
public class Launcher {

	private TaskManager taskManager;

	public Launcher() {
		taskManager = new TaskManager();
	}

	public void launch(MobileApplication mobileApp) {

		mobileApp.start();
		taskManager.newAppLoaded(mobileApp);
		// mobileApp.pause();
		// mobileApp.stop();
	}

	public int runningAppsCount() {
		return taskManager.getNumberOfRunningApps();
	}

	public void closeAllApps() {
		taskManager.closeAllRunningApps();
	}
}
