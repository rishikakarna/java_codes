package com.lti.training.day3.interfaces;

public class MyMobileApplication1 implements MobileApplication{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("MyMobileApplication1 started.........");
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		System.out.println("MyMobileApplication1 paused.........");
	}
	
	@Override
	public void stop() {
		// TODO Auto-generated method stub
		System.out.println("MyMobileApplication1 stopped.........");
	}

}
