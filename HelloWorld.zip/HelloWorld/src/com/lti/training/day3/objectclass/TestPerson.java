package com.lti.training.day3.objectclass;

public class TestPerson {

	public static void main(String[] args) throws CloneNotSupportedException {
		Person p1 = new Person();
		p1.setName("LUFFY");
		p1.setAge(21);
		// Person p1 = new Person("LUFFY" , 21); //not readable
		System.out.println(p1.getName() + " , " + p1.getAge());
		System.out.println(p1);
		// in println()-->toString() o/p displayed is
		// com.lti.training.day3.objectclass.Person@70dea4e @70dea4e:hashcode

		Person p2 = new Person("LUFFY", 21);

		System.out.println(p1 == p2); // reference comparison
		System.out.println(p1.equals(p2)); // value comparison

		// hashCode
		System.out.println(p1.hashCode());
		System.out.println(p2.hashCode());

		// clone
		// shallow
		Person p3 = (Person) p1.clone();
		System.out.println(p3);

		Address adr = new Address("Mumbai", 400706);
		Person p4 = new Person("LUFFY", 99, adr);

		Person p5 = (Person) p4.clone();

		System.out.println(p4.getAddress().getCity());
		System.out.println(p5.getAddress().getCity());

		p4.getAddress().setCity("Delhi");
		System.out.println(p4.getAddress().getCity());
		System.out.println(p5.getAddress().getCity());
		// shallow end
		p1 = null;
		System.gc(); // never to use in live projects
	}
}