package com.lti.training.day3.abstraction.v1;

public class TestLogger {

	public static void main(String[ ] args) {
		Logger logger = new  Logger();
		logger.log("Some happy msg");
		logger.log("maybe some concern to address", LogLevel.WARN);
		logger.log("some critical situation has arrised", LogLevel.ERROR);
	}
}
