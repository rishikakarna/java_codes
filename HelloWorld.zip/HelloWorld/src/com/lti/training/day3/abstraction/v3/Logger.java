package com.lti.training.day3.abstraction.v3;

public class Logger {
	
	public void log(String msg) {
		//	System.out.println("[INFO] ["+LocalDate.now()+"]"+ " " + msg);
			log(msg, LogLevel.INFO);		//reusing 2nd log
		}

	public void log(String msg, LogLevel level) {
	
	}
}
