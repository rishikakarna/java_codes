package com.lti.training.day6.multitreading;

class BankAccount {

	int acno;
	double balance;

	/**
	 * @param acno
	 * @param balance
	 */
	public BankAccount(int acno, double balance) {
		super();
		this.acno = acno;
		this.balance = balance;
	}

	public synchronized void withdraw(double amount) {
		try {
			Thread.sleep(100);
		} catch (Exception e) {
		}
		if (amount < balance) {
			try {
				Thread.sleep(100);
			} catch (Exception e) {
			}
			balance -= amount;
			try {
				Thread.sleep(200);
			} catch (Exception e) {
			}
			System.out.println("Balance left " + balance);
		} else
			System.out.println("Insufficient balance!!!!!!!");
	}
}

class Transaction implements Runnable {

	BankAccount bankAccount;

	Transaction(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}

	@Override
	public void run() {

		bankAccount.withdraw(5000);

	}

}

public class Example3 {

	public static void main(String[] args) {
		BankAccount bankAcc = new BankAccount(1111, 6000);
		Transaction tx1 = new Transaction(bankAcc);
		Transaction tx2 = new Transaction(bankAcc);
		Thread th1 = new Thread(tx1);
		Thread th2 = new Thread(tx2);
		th1.start();
		th2.start();
	}
}
