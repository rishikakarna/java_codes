package com.lti.training.day6.stream;

//for image processing....imageio class

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.IOException;

public class WriteFile {

	public static void main(String[] args) {
		FileOutputStream outFile = null;
		FileInputStream inFile = null;
		// FileWriter outFile = null;
		// FileReader inFile = null;
		try {
			// inFile = new FileInputStream("car.jpg");
			// outFile = new FileOutputStream("car1.jpg"); // for media...
			inFile = new FileInputStream("D:\\jdk-8u131-windows-x64.exe");
			outFile = new FileOutputStream("D:\\jdk-8u131-windows-x64 - Copy.exe");
			// inFile = new FileReader("car.jpg");
			// outFile = new FileWriter("car1.jpg"); ///for text
			int ch = 0;
			while (true) {
				ch = inFile.read();
				if (ch == -1) // EOF
					break;
				outFile.write(ch);
			}
			System.out.println("File copied successfully");

		} catch (FileNotFoundException e) {
			System.out.println("Please check the no.of of your glasses!");
		} catch (IOException e) {
			System.out.println("Please contact Mr Santosh");
		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
			}
			try {
				outFile.close();
			} catch (Exception e) {
			}
		}

	}

}
