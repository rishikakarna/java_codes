package com.lti.training.day6.stream;

//for image processing....imageio class
//this program copies the data of file to another using buffer

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class QuickWriteFile {

	public static void main(String[] args) {
		FileOutputStream outFile = null;
		FileInputStream inFile = null;
		BufferedInputStream inBuffer = null;
		BufferedOutputStream outBuffer = null;
		try {
			inFile = new FileInputStream("D:\\jdk-8u131-windows-x64.exe");
			outFile = new FileOutputStream("D:\\jdk-8u131-windows-x64 - Copy.exe");
			inBuffer = new BufferedInputStream(inFile);
			outBuffer = new BufferedOutputStream(outFile);

			int ch = 0;
			while (true) {
				ch = inBuffer.read();
				if (ch == -1) // EOF
					break;
				outBuffer.write(ch);
			}
			System.out.println("File copied successfully");

		} catch (FileNotFoundException e) {
			System.out.println("Please check the no.of of your glasses!");
		} catch (IOException e) {
			System.out.println("Please contact Mr Santosh");
		} finally {
			try {
				inBuffer.close();
			} catch (Exception e) {
			}
			try {
				outBuffer.close();
			} catch (Exception e) {
			}
			try {
				inFile.close();
			} catch (Exception e) {
			}
			try {
				outFile.close();
			} catch (Exception e) {
			}
		}
	}
}
