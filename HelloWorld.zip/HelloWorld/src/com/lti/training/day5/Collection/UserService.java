package com.lti.training.day5.Collection;

import java.util.HashMap;
//all about map
import java.util.Map;

public class UserService {

	private Map<String, String> users;

	public UserService() {
		users = new HashMap<>();
		users.put("ash", "123");
		users.put("brock", "456");
		users.put("misty", "788");
		users.put("pichu", "159");
	}

	public boolean isValidUser(String username, String password) {
		if (users.containsKey(username)) {
			String pswd = users.get(username);
			if (pswd.equals(password))
				return true;
		}
		return false;
	}

	public static void main(String[] args) {
		UserService userManager = new UserService();
		boolean isValid = userManager.isValidUser("ash", "193");
		System.out.println(isValid);
	}
}
