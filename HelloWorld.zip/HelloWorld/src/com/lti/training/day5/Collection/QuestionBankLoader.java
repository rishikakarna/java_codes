package com.lti.training.day5.Collection;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//main app
public class QuestionBankLoader {

	private QuestionBank questionBank;

	public QuestionBankLoader() {
		questionBank = new QuestionBank();
	}

	public void loadQuestionOnJava() {
		questionBank.addNewSubject("Java");

		Question q = new Question();
		q.setQuestion("what is class?");
		List<Option> options = new ArrayList<>();
		Option o1 = new Option("class is template", true);
		Option o2 = new Option("class is classroom", false);
		Option o3 = new Option("class is datatype", false);
		Option o4 = new Option("class is class", false);
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);

		q = new Question();
		q.setQuestion("what is object?");
		options = new ArrayList<>();
		/*
		 * o1 = new Option("class is template", true); o2 = new
		 * Option("class is classroom", false); o3 = new Option("class is datatype",
		 * false); o4 = new Option("class is class", false);
		 */
		options.add(new Option("object is prototype", false));
		options.add(new Option("object is instance of class", true));
		options.add(new Option("object is object", false));
		options.add(new Option("object is primitive type", false));
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);

		q = new Question();
		q.setQuestion("what is G1?");
		options = new ArrayList<>();
		/*
		 * o1 = new Option("class is template", true); o2 = new
		 * Option("class is classroom", false); o3 = new Option("class is datatype",
		 * false); o4 = new Option("class is class", false);
		 */
		options.add(new Option("G1 is another name of Jeevan", false));
		options.add(new Option("G1 is name of spy movie", false));
		options.add(new Option("G1 is garbage collection in java", true));
		options.add(new Option("G1 is sequel of SRK movie Ra.One", false));
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
	}

	public void startExam() {
		Scanner sc = new Scanner(System.in);
		int score = 0;

		List<Question> questions = questionBank.getQuestionsFor("Java");
		for (Question question : questions) {
			System.out.println("Q." + question.getQuestion());
			for (Option option : question.getOptions()) {
				System.out.println(option.getOption());
			}
			System.out.print("Enter correct option (1-4)");
			int ans = sc.nextInt();

			Option selectedOption = question.getOptions().get(ans - 1);
			if (selectedOption.isRightAnswer())
				score++;
		}
		System.out.println("\n\n You Have scored " + score + " out of  " + questions.size());
	}

	public static void main(String[] args) {
		QuestionBankLoader qb1 = new QuestionBankLoader();
		qb1.loadQuestionOnJava();
		qb1.startExam();
	}
}
