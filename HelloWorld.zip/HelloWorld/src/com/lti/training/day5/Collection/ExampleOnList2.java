package com.lti.training.day5.Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.lti.training.day3.objectclass.Person;

public class ExampleOnList2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// <>angular notation is called generics in java & its optional
		List<String> list1 = new ArrayList<String>();
		// List list1 = new ArrayList();
		list1.add("Java");
		list1.add("Oracle");
		list1.add(".Net");
		list1.add("PHP");
		list1.add(1, "Java");
		
		List<String> list2 = new ArrayList<String>();
		list2.add("luffy");
		list2.add("nami");
		list2.add("zoro");
		list2.add("chopper");
		list2.add(1, "franky");

		list1.addAll(list2);
		list2.contains("franky");
		 System.out.println("option 2: using for each-loop"); //most frequently used
		  for (String str : list1) System.out.println(str); 
		  
	
		
		 
	}
}
