package com.lti.training.day5.Collection;

//every qtns have multiple option(or)choices
public class Option {

	private String option;
	private boolean isRightAnswer;

	public Option() {
	}

	/**
	 * @param option
	 * @param isRightAnswer
	 */
	public Option(String option, boolean isRightAnswer) {
		super();
		this.option = option;
		this.isRightAnswer = isRightAnswer;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public boolean isRightAnswer() {
		return isRightAnswer;
	}

	public void setRightAnswer(boolean isRightAnswer) {
		this.isRightAnswer = isRightAnswer;
	}

}
