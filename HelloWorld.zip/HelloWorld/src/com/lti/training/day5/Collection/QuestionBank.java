package com.lti.training.day5.Collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionBank { // stores all questions of subject

	private Map<String, List<Question>> questionBank; // <name of subject, list of question> //map<k,v>

	public QuestionBank() {
		questionBank = new HashMap<>();
	}

	public void addNewSubject(String subject) {
		questionBank.put(subject, new ArrayList<>());
	}

	public void addNewQuestion(String subject, Question question) {
		List<Question> questions = questionBank.get(subject); // gets empty list at start..
		questions.add(question);
	}

	public List<Question> getQuestionsFor(String subject) {
		return questionBank.get(subject);
	}

}
