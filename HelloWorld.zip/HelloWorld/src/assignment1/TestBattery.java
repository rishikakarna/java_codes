package assignment1;

public class TestBattery {

	public static void main(String[] args) {

	}

}
