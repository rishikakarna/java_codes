package assignment1;

public class Battery implements Cloneable {

	private static int seq = 1;
	private String name;
	private int batteryno;

	public Battery() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param name
	 * @param batteryno
	 */
	public Battery(String name, int batteryno) {
		super();
		this.name = name;
		this.batteryno = seq++;
	}

	public static int getSeq() {
		return seq;
	}

	public static void setSeq(int seq) {
		Battery.seq = seq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBatteryno() {
		return batteryno;
	}

	@Override
	public String toString() {
		return "Battery [name=" + name + ", batteryno=" + batteryno + "]";
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

}
