package practice;

public class Child2 extends Child1 {
	public void sub() {
		System.out.println("child 2 sub method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child2 c1 = new Child2();
		c1.add();
		c1.mul();
		Child1 a = new Child2();
//		Child2 x = (Child2) new Child1();
//		x.mul();
	}

}
