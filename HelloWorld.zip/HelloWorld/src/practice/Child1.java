package practice;

public class Child1 extends Parent {
public void add()
{
	System.out.println("chaild1 mathod");
	}
public void sub()
{
	System.out.println("child 1 sub method");}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child1 c = new Child1();
		c.add();
	}

}
